#  Add your API key
omdb_key = "903ecec6"
ny_key = "kXWfoy6U2S3OaA7FmvsCJL96xFGMaw83"
weather_key = "38b9e1d666bbbb86cb9f6ed120272dd2"
census_key = "6c5eb3c7621354c887a15873c47011cf6a980b15"
geo_key = "cdc2e6bea5cd48cfb19a22de29a75c86"
weatherbit_key = "1ac4902a8789400d93aca85734a90e84"